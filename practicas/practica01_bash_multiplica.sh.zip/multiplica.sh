#!/bin/bash

# Comprobar si se proporcionó un argumento y si el número está en el rango válido
if [ $1 -ge 1 ] && [ $1 -le 10 ]; then

	# Asignar el argumento a la variable n
	n=$1

	# Bucle for para iterar del 1 al 10
	for i in {1..10}; do
	  # Calcular el resultado de la multiplicación y mostrarlo en la consola
	  echo "$n * $i = $((i * n))"
	done

else

  echo "Debe ingresar un número del 1 al 10 como argumento."
  exit 1

fi
