'''
tabla = 5
i = 1
while i <= 10:
    print (f"{tabla} x {i} = {tabla * i}")
    i = i + 1
'''

# ejercicio tabla de multiplicar con for
tabla = 5

for i in range(1, 11): # el número siguiente al que queremos que se pare
    print (f"{tabla} x {i} = {tabla * i}")

# ejercicio listar de cinco en cinco
for i in range(0, 101, 5): print (i)

'''
Ejercicio para usar el bucle «for»:
Hacer un programa que simule tirar tres dados, muestre el valor de cada dado y
sume el valor de los tres en cada tirada. Luego, mostrar el resultado de la suma
de los tres dados.
'''

import random

total = 0

for i in range(3):
    dado = random.randrange(1, 7)
    print(f"Tirada {i + 1}: {dado}")
    total += dado # total = total + dado

print(f"En total has obtenido {total} punto(s).")

# ejercicio listar caracteres de una cadena
for i in "¡AMIGO!":
    print ("dame una ", i)

# ejercicio uso de listas
dias_semana = ["lunes", "martes", "miércoles", "jueves", "viernes"]
for i in dias_semana:
    print (i, "es un día laborable.")

# ejercicio uso de diccionario
dias_semana = {"lunes" : 1, "martes": 2, "miércoles": 3}
print ("El orden del día martes es:", dias_semana["martes"])


'''
Temas necesarios para seguir estudiando en Python:

- Conocer más sobre los bucles for
- Uso de listas: añadir datos, quitar datos, ordenar listas...
- Diferencias entre listas y tuplas
- Uso de diccionarios
- Uso de funciones en Python

'''
