'''
numero = 0

while numero < 1 or numero > 10:
    numero = int(input ("Dime un número del 1 al 10: "))
'''

correcto = False

while correcto == False:
    numero = int(input ("Dime un número del 1 al 10: "))
    if numero >= 1 and numero <= 10:
        correcto = True

i = 1 # contador

while i <= 10:
    print (f"{numero} x {i} = {numero * i}")
    i = i + 1

print ("Fin")

