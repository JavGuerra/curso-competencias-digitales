numero = 2
numero2 = 2.0 # float (coma flotante)

print (numero + numero2) # suma
print (int("2") + numero)
print (float("2") + numero) 
print (numero - numero2) # resta
print (numero * numero2) # multiplicación
print (numero / numero2) # división
print (numero ** numero2) # potencia
print (numero % numero2) # módulo (parte entera) de la división

# numero valía 2, porque lo definimos antes
numero = numero + numero
#  4   =    2   +   2 
# lo que decimos es que 2 + 2 = 4
# numero + numero => numero (el resultado de la operación se mete en la varialbe)
# ahora número sería igual a 4

# operadores
numero += numero
numero -= numero
numero *= numero # numero = numero * numero
numero /= numero # numero = numero / numero

numero = numero + 1
# numero++  forma equivalente de sumar 1 de uso común en otros lenguajes

# Concatenar / concatenación
# Concatenar NO es sumar, es añadir

print ("  Hola" + " mundo")

texto = "     Hola     ".strip() # limpiamos los espacios antes y después
print (texto, "su longitud es: ", len(texto)) # len obtiene la longitud

texto2 = texto + ", su longitud es: " + str(len(texto))
print (texto2, len(texto2)) # str convierte a cadena de texto (string)

# cadenas y variables

numero3 = 5
print ("El número es: " + str(numero3))
# la f dice a print que debe interpretar el contenido de la cadena
print (f"El número es: {numero3}")

print (f"Lorem ipsum dolor sit amet, consectetur adipiscing elit,\n sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\n quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.\n Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.")

print ("""'Lorem ipsum dolor sit amet, consectetur adipiscing elit,
sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.
Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris
nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in
reprehenderit in voluptate velit esse cillum dolore eu fugiat
nulla pariatur. Excepteur sint occaecat cupidatat non proident,
sunt in culpa qui officia deserunt mollit anim id est laborum.'""")

print ('"Texto con comillas"')

