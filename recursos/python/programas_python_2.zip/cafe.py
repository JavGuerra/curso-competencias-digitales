# Café

'''
Preguntar por pantalla si hemos tomado café. El usuario podrá responder S o N.
Si no hemos tomado café, salir del programa.
Si hemos tomado café debemos imprimir un aviso de que estamos listos.
'''

cafe = False

tomar = input("¿Has tomado café? (S/N): ")

if tomar == "S" or tomar == "s": cafe = True

if not cafe: exit ("ZzZzZz Ve a dormir")

print ("Listo para seguir")


'''
Programa alternativo

tomar = input("¿Has tomado café? (S/N): ")
if not tomar.upper() == "S": exit ("ZzZzZz Ve a dormir")
print ("Listo para seguir")
'''

