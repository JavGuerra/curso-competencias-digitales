# Lotería

comprar = True # booleano True / False
tocar   = False
cambiar = True

# if (verdadero) entonces...
#    True       True      False
if (comprar and tocar and cambiar):
    print ("¡Millonario!")
else:
    print ("Me quedo igual...")

'''
if not (comprar and tocar and cambiar):
    print ("Sigue jugando")
else:
    print ("¡Fiesta!")
'''


