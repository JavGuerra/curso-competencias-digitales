resultado = '0'

for i in range(1, 101):
    resultado = resultado + ', '
    x3 = i % 3 == 0
    x5 = i % 5 == 0

    if (not x3 and not x5):
        resultado = resultado + str(i)
    else:
        if (x3): resultado = resultado + 'fizz'
        if (x5): resultado = resultado + 'buzz'

print (resultado)
