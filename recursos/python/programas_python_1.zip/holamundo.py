'''
Hola Mundo
Javier
fguerra@goodjob.es
29-5-2023
v. 1.0.0
'''

# Poner aquí la definición de variables

print ("Hola Mundo")

# ejercicio

numero = 2.4
texto = "2.4"
booleano = False

print (numero, texto, booleano)

# ejercicio

nombre = "Javier Guerra"
nombre = input ("Introduce un nombre: ")
print ("Mi nombre es:", nombre)

# ejercicio

edad = input ("¿Cuál es tu edad? ")
edad = int(edad)
print ("mi edad es:", edad, type(edad))

# condicionales

if booleano == True:
    print ("el valor es verdadero.")

# ejercicio

nombre = "Javier"
nuevo_nombre = input ("Adivina mi nombre: ")
if nombre == nuevo_nombre:
    print ("¡Acertaste!")
else:
    print ("No acertaste...")

# ejercicio

edad = 54
nueva_edad = int (input ("¿Qué edad tengo? "))

'''
if edad == nueva_edad:
    print ("¡Acertaste!")
else:
    if edad > nueva_edad:
        print ("Te has quedado corto.")
    else:
        print ("Te has pasado.")
'''

# Ver cómo el uso de elif sustituye a else + if

if edad == nueva_edad:
    print ("¡Acertaste!")
elif edad > nueva_edad:
    print ("Te has quedado corto.")
else:
    print ("Te has pasado.")