import random

numero_aleatorio = random.randint(1, 10)
adivinado = False

while not adivinado:
    numero = int(input("Adivina el número entre 1 y 10: "))
    if numero == numero_aleatorio:
        print("¡Correcto! El número era", numero_aleatorio)
        adivinado = True
    elif numero < numero_aleatorio:
        print("El número es demasiado bajo, intenta de nuevo.")
    else:
        print("El número es demasiado alto, intenta de nuevo.")